const jwt = require('jsonwebtoken');

const GenerateToken = (payload) => {
    const key = 'vf0i54m8jgsldmpgrte-j';
    const options = {
        expiresIn:'1h',
    };
    const token = jwt.sign(payload,key,options);
    return token;
};
module.exports = {
    GenerateToken,
}