const express = require('express');
const app = express();

const bodyParser = require('body-parser');

const {GenerateToken} = require('./Token');

const mongoose = require('mongoose');
const User = require('./models/User.js')

const path = require('path');

app.use(bodyParser.json());

app.use(express.json());

//--------------------- Send website to user ---------------------
const port = process.env.PORT || 3000;
app.use(express.static(__dirname + "/src/public"));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, './src/index.html'));
});
app.listen(port);
console.log('Server started at http://localhost:' + port);
//----------------------------------------------------------------

//--------------------- authentication ---------------------------
// validation middleware
const jwt = require('jsonwebtoken');
const validateToken = (req,res,next) =>{
    const authHeader = req.headers.authorization;
    if(authHeader){
        const token = authHeader.split(' ')[1];

        jwt.verify(token, 'yourSecretKey', (err, payload) => {
            if (err) {
              return res.status(403).json({
                success: false,
                message: 'Invalid token',
              });
            } else {
              req.user = payload;
              next();
            }
          });
        } else {
          res.status(401).json({
            success: false,
            message: 'Token is not provided',
          });
        }
}
//
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, './src/login.html'));
});
app.post('/login', async (req, res) => {
    const {Username, Password}  = req.body;

    const user = await User.find({username:"${Username}"});
    if(Password === user.password){
      const token = GenerateToken({id: user.id, username: user.username});

      res.json({
          success: true,
          message: 'Authentication successful!',
          token: token,
        });
      } else {
        res.status(401).json({
          success: false,
          message: 'Invalid username or password',
        });
      }
});

app.get('/protected', validateToken, (req, res) => {
    res.json({
      success: true,
      message: 'Welcome to the protected route!',
      user: req.user,
    });
  });
//----------------------------------------------------------------
//--------------------- db integration ---------------------------
//----------------------------------------------------------------
// algorythm for integration with authentication user data ie username => query for others that username => check if password is equal=> if not fail if so authenticate 
app.post('/signin/', async(req,res)=>{ //add email verification 
  try{
      const user = await User.create(req.body);
      res.status(200).json(user);
  }
  catch(error){
      console.log(error);
      res.status(500).json({message: error.message});
  }
})
app.get('/login/test', async(req,res)=>{
  try{
    const Username = "nigger2";
    const user = await User.find({username:Username});
    res.status(200).json(user);
  }
  catch(error){
      console.log(error);
      res.status(500).json({message: error.message});
  }
})
mongoose.connect("mongodb://localhost:27017/")
.then(() =>{
    console.log("Connected To Database");
})
.catch(()=>{
    console.log("Failed To Connect To Database");
})